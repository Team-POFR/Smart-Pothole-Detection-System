package com.surendramaran.yolov8tflite

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.absoluteValue

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private val markers = mutableListOf<Marker>()
    private val proximityThreshold = 20 // meters
    private lateinit var locationReceiver: BroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish()
        }

        locationReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val latitude = intent?.getDoubleExtra("latitude", 0.0) ?: 0.0
                val longitude = intent?.getDoubleExtra("longitude", 0.0) ?: 0.0
                val location = Location("").apply {
                    this.latitude = latitude
                    this.longitude = longitude
                }
                checkProximityToMarkers(location)
            }
        }
        registerReceiver(locationReceiver, IntentFilter("com.surendramaran.yolov8tflite.LOCATION_UPDATE"))

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        startService(Intent(this, LocationService::class.java))
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        enableMyLocation()
        clearMarkers()  // Clear markers every time the map is ready
        fetchCoordinates()  // Fetch new coordinates and add new markers
    }

    private fun fetchCoordinates() {
        Executors.newSingleThreadExecutor().execute {
            try {
                val url = URL("http://192.168.1.35:8000")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connect()

                if (connection.responseCode == 200) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    val jsonResponse = JSONObject(response)
                    val gpsLog = jsonResponse.getJSONArray("gps_log")
                    val accelerometerLog = jsonResponse.getJSONArray("accelerometer_log")
                    val gyroscopeLog = jsonResponse.getJSONArray("gyroscope_log")
                    runOnUiThread {
                        displayCoordinates(gpsLog, accelerometerLog, gyroscopeLog)
                    }
                } else {
                    Log.e("MapActivity", "Error fetching coordinates")
                }
            } catch (e: Exception) {
                Log.e("MapActivity", "Exception: ${e.message}")
            }
        }
    }

    private fun clearMarkers() {
        Log.d("MapActivity", "Clearing markers")
        for (marker in markers) {
            marker.remove()
        }
        markers.clear()
    }

    private fun displayCoordinates(gpsLog: JSONArray, accelerometerLog: JSONArray, gyroscopeLog: JSONArray) {
        // Aggregate sensor values by detection ID
        val aggregatedSensorData = mutableMapOf<String, MutableList<JSONObject>>()

        for (i in 0 until accelerometerLog.length()) {
            val accObject = accelerometerLog.getJSONObject(i)
            val detectionId = accObject.getString("detection_id")
            if (aggregatedSensorData[detectionId] == null) {
                aggregatedSensorData[detectionId] = mutableListOf()
            }
            aggregatedSensorData[detectionId]?.add(accObject)
        }

        for (i in 0 until gyroscopeLog.length()) {
            val gyroObject = gyroscopeLog.getJSONObject(i)
            val detectionId = gyroObject.getString("detection_id")
            if (aggregatedSensorData[detectionId] == null) {
                aggregatedSensorData[detectionId] = mutableListOf()
            }
            aggregatedSensorData[detectionId]?.add(gyroObject)
        }

        // Process GPS logs and match with sensor data
        for (i in 0 until gpsLog.length()) {
            val gpsObject = gpsLog.getJSONObject(i)
            val lat = gpsObject.getDouble("latitude")
            val lng = gpsObject.getDouble("longitude")
            val detectionId = gpsObject.getString("detection_id")
            val location = LatLng(lat, lng)

            val sensorDataList = aggregatedSensorData[detectionId] ?: continue

            val maxAccel = sensorDataList
                .filter { it.getString("type") == "accelerometer" }
                .flatMap { listOf(it.getDouble("x"), it.getDouble("y") - 8, it.getDouble("z") - 3.5) }
                .map { it.absoluteValue }
                .maxOrNull() ?: 0.0

            val maxGyro = sensorDataList
                .filter { it.getString("type") == "gyroscope" }
                .flatMap { listOf(it.getDouble("x"), it.getDouble("y"), it.getDouble("z")) }
                .map { it.absoluteValue }
                .maxOrNull() ?: 0.0

            val markerTitle = classifyPothole(maxAccel.toFloat(), maxGyro.toFloat())
            Log.d("MapActivity", "Marker $i: $markerTitle (maxAccel=$maxAccel, maxGyro=$maxGyro)")

            val marker = map.addMarker(MarkerOptions()
                .position(location)
                .title(markerTitle)
            )
            marker?.let { markers.add(it) }

            if (i == 0) {
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 10f))
            }
        }
    }

    private fun classifyPothole(maxAccel: Float, maxGyro: Float): String {
        val maxReading = maxOf(maxAccel, maxGyro)

        return when {
            maxReading > 25-> "Severe Pothole : $maxAccel , $maxGyro"
            maxReading > 13 && maxReading <= 25 -> "Moderate Pothole : $maxAccel , $maxGyro"
            else -> "Minor Pothole : $maxAccel , $maxGyro"
        }
    }

    private fun checkProximityToMarkers(location: Location) {
        for (marker in markers) {
            val markerLocation = Location("").apply {
                latitude = marker.position.latitude
                longitude = marker.position.longitude
            }

            val distance = location.distanceTo(markerLocation)
            if (distance < proximityThreshold) {
                Toast.makeText(this, "Warning: You are close to a marker!", Toast.LENGTH_LONG).show()
                break
            }
        }
    }

    private fun enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            map.isMyLocationEnabled = true
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                enableMyLocation()
                startService(Intent(this, LocationService::class.java))
            } else {
                Toast.makeText(this, "Permission denied to access location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(locationReceiver)
    }
}
